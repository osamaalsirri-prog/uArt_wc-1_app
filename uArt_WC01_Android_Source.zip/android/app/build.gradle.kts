plugins { id("com.android.application") }
android {
    namespace = "com.uart.wc01"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.uart.wc01"
        minSdk = 26
        targetSdk = 35
        versionCode = 12
        versionName = "6.1.1"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
