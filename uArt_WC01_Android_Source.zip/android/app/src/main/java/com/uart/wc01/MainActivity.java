package com.uart.wc01;

import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

/**
 * uArt WC-01 companion app shell.
 * Only local bundled assets are rendered at http://wc01.test/ (a reserved .test host).
 * ESP32 calls are made explicitly to a private LAN IP after user pairing and CORS approval.
 * An append/status/export-only local diagnostics bridge is registered; no machine-control bridge, file:// access or untrusted page navigation.
 */
public final class MainActivity extends Activity {
    private static final String LOCAL_HOST = "wc01.test";
    private static final String LOCAL_BASE = "http://wc01.test/";
    public static final int EXPORT_ARCHIVE_REQUEST = 77;
    private WebView webView;
    private DiagnosticArchive archive;
    private WiFiRoute wifiRoute;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(5, 8, 13));
        getWindow().setNavigationBarColor(Color.rgb(5, 8, 13));
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(Color.rgb(5, 8, 13));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(5, 8, 13));
        frame.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frame);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        // Log bridge has only append/status/export methods. No arbitrary file I/O or device control.
        archive = new DiagnosticArchive(this);
        webView.addJavascriptInterface(archive, "WC01NativeLogs");
        webView.addJavascriptInterface(new PairingStore(this), "WC01Pairing");
        wifiRoute = new WiFiRoute(this);
        webView.addJavascriptInterface(wifiRoute, "WC01Network");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                return !(req.isForMainFrame() && isLocalAssetUri(u));
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (!isLocalAssetUri(u)) return null;
                String path = u.getPath();
                if (path == null || path.equals("/")) path = "/index.html";
                String name = path.substring(1);
                // Only expected paths; reject traversal and unknown assets.
                if (!name.matches("(?:index\\.html|css/style\\.css|js/(?:app|diagnostics)\\.js|images/[a-z0-9-]+\\.(?:webp|svg|png))")) {
                    return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", null,
                            new java.io.ByteArrayInputStream(new byte[0]));
                }
                String mime = name.endsWith(".html") ? "text/html" : name.endsWith(".css") ? "text/css"
                        : name.endsWith(".js") ? "application/javascript" : name.endsWith(".svg") ? "image/svg+xml" : name.endsWith(".png") ? "image/png" : "image/webp";
                try {
                    InputStream data = getAssets().open(name);
                    return new WebResourceResponse(mime, "UTF-8", data);
                } catch (IOException ex) {
                    return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", null,
                            new java.io.ByteArrayInputStream(new byte[0]));
                }
            }
        });
        webView.loadUrl(LOCAL_BASE);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == EXPORT_ARCHIVE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            archive.writeArchive(data.getData(), () -> {
                if (webView != null) {
                    webView.evaluateJavascript("(function(){if(window.__wc01ArchiveExportDone)window.__wc01ArchiveExportDone()})()", null);
                }
            });
        }
    }
    private boolean isLocalAssetUri(Uri u) {
        return "http".equalsIgnoreCase(u.getScheme()) && LOCAL_HOST.equalsIgnoreCase(u.getHost())
                && (u.getPort() == -1 || u.getPort() == 80);
    }
    @Override public void onBackPressed() {
        if (webView != null) webView.evaluateJavascript("(function(){if(window.__wc01Back)window.__wc01Back();})();", null);
        else super.onBackPressed();
    }
    public void notifyNetworkChanged() {
        if (webView != null) webView.evaluateJavascript("(function(){if(window.__wc01NetworkChanged)window.__wc01NetworkChanged()})()", null);
    }
    @Override protected void onStart() {
        super.onStart();
        if (wifiRoute != null) wifiRoute.onStart();
    }
    @Override protected void onResume() {
        super.onResume();
        if (wifiRoute != null) wifiRoute.refresh();
        notifyNetworkChanged();
    }
    @Override protected void onStop() {
        if (wifiRoute != null) wifiRoute.onStop();
        super.onStop();
    }
    @Override protected void onDestroy() {
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
