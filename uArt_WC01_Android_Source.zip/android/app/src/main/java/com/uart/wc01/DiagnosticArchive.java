package com.uart.wc01;

import android.app.Activity;
import android.net.Uri;
import android.webkit.JavascriptInterface;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Persistent uArt WC-01 diagnostics, available only to bundled first-party WebView assets.
 * Appends + fsyncs each event into app-private filesDir/wc01_diagnostics/.
 * Daily and 512-KiB size rotation; no silent deletion of archived events.
 * Files can be exported via ACTION_CREATE_DOCUMENT to a ZIP selected by the user.
 * This log is a support trace, not a tamper-proof safety audit log.
 */
public final class DiagnosticArchive {
    private static final int MAX_LINE_CHARS = 3000;
    private static final long MAX_FILE_BYTES = 512L * 1024L;
    private static final long LOW_SPACE_BYTES = 2L * 1024L * 1024L;
    private final Activity activity;
    private final File folder;
    private final Object lock = new Object();
    private String lastError = "";

    DiagnosticArchive(Activity activity) {
        this.activity = activity;
        this.folder = new File(activity.getFilesDir(), "wc01_diagnostics");
        if (!folder.exists() && !folder.mkdirs()) lastError = "Unable to create log directory";
    }

    @JavascriptInterface public boolean appendRecord(String json) {
        synchronized (lock) {
            try {
                if (json == null || json.length() > MAX_LINE_CHARS) throw new IllegalArgumentException("Invalid record size");
                JSONObject incoming = new JSONObject(json);
                JSONObject safe = new JSONObject();
                safe.put("time", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US).format(new Date()));
                safe.put("appTime", incoming.optString("time", "").substring(0, Math.min(incoming.optString("time", "").length(), 40)));
                safe.put("level", restrictLevel(incoming.optString("level", "info")));
                safe.put("text", cap(incoming.optString("text", ""), 500));
                safe.put("mode", "live".equals(incoming.optString("mode")) ? "live" : "demo");
                safe.put("source", "uArt WC-01");
                safe.put("appVersion", "4.0.0");
                byte[] line = (safe.toString() + "\n").getBytes(StandardCharsets.UTF_8);
                if (activity.getFilesDir().getUsableSpace() < LOW_SPACE_BYTES) throw new IllegalStateException("Low device storage");
                File target = nextFile(line.length);
                try (FileOutputStream out = new FileOutputStream(target, true)) {
                    out.write(line);
                    out.getFD().sync(); // save each event immediately; not only on app close
                }
                lastError = "";
                return true;
            } catch (Exception e) {
                lastError = cap(e.getClass().getSimpleName() + ": " + e.getMessage(), 180);
                return false;
            }
        }
    }

    private File nextFile(int bytes) {
        String day = new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
        for (int part = 1; part <= 9999; part++) {
            File result = new File(folder, String.format(Locale.US, "WC01_%s_%04d.jsonl", day, part));
            if (!result.exists() || result.length() + bytes <= MAX_FILE_BYTES) return result;
        }
        throw new IllegalStateException("Too many daily log files");
    }
    private static String restrictLevel(String s) { return "error".equals(s) || "warn".equals(s) ? s : "info"; }
    private static String cap(String s, int max) { return s == null ? "" : s.substring(0, Math.min(s.length(), max)); }
    private File[] listLogFiles() {
        File[] files = folder.listFiles(f -> f.isFile() && f.getName().matches("WC01_[0-9]{8}_[0-9]{4}\\.jsonl"));
        if (files == null) files = new File[0];
        Arrays.sort(files, (a, b) -> a.getName().compareTo(b.getName()));
        return files;
    }

    @JavascriptInterface public String getArchiveStats() {
        synchronized (lock) {
            JSONObject status = new JSONObject();
            File[] files = listLogFiles();
            long bytes = 0, mostRecent = 0;
            for (File f : files) { bytes += f.length(); mostRecent = Math.max(mostRecent, f.lastModified()); }
            try {
                status.put("native", true);
                status.put("files", files.length);
                status.put("bytes", bytes);
                status.put("last", mostRecent > 0 ? new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US).format(new Date(mostRecent)) : JSONObject.NULL);
                status.put("error", lastError);
            } catch (Exception ignored) {}
            return status.toString();
        }
    }

    /** Opens system save picker. Never writes to arbitrary paths supplied by web content. */
    @JavascriptInterface public void exportArchive() {
        activity.runOnUiThread(() -> {
            android.content.Intent save = new android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT);
            save.addCategory(android.content.Intent.CATEGORY_OPENABLE);
            save.setType("application/zip");
            String date = new SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(new Date());
            save.putExtra(android.content.Intent.EXTRA_TITLE, "uArt_WC01_Diagnostics_" + date + ".zip");
            activity.startActivityForResult(save, MainActivity.EXPORT_ARCHIVE_REQUEST);
        });
    }

    /** Called only from MainActivity after the Android SAF picker grants permission. */
    public void writeArchive(Uri chosenUri, Runnable finished) {
        new Thread(() -> {
            try {
                synchronized (lock) {
                    try (OutputStream stream = activity.getContentResolver().openOutputStream(chosenUri, "w")) {
                        if (stream == null) throw new IllegalStateException("File destination cannot be opened");
                        try (ZipOutputStream zip = new ZipOutputStream(stream)) {
                            byte[] buffer = new byte[16384];
                            for (File file : listLogFiles()) {
                                zip.putNextEntry(new ZipEntry(file.getName()));
                                try (FileInputStream in = new FileInputStream(file)) {
                                    int n; while ((n = in.read(buffer)) != -1) zip.write(buffer, 0, n);
                                }
                                zip.closeEntry();
                            }
                            zip.finish();
                        }
                    }
                    lastError = "";
                }
            } catch (Exception e) { lastError = cap("Export failed: " + e.getMessage(), 180); }
            activity.runOnUiThread(finished);
        }, "WC01-LogExport").start();
    }
}
