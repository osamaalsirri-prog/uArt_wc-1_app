package com.uart.wc01;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.webkit.JavascriptInterface;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.Arrays;
import java.util.regex.Pattern;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Stores the independent WC-01 application pairing key encrypted in Android Keystore.
 * Only the built-in http://wc01.test origin is allowed to render in MainActivity.
 * The Wi-Fi password is NOT stored here; Android itself manages Wi-Fi credentials.
 */
public final class PairingStore {
    private static final String ALIAS = "com.uart.wc01.pairing.v1";
    private static final String PREFS = "wc01_pairing_private";
    private static final String ENTRY = "encrypted_key";
    private static final Pattern KEY_FORMAT = Pattern.compile("[A-Za-z0-9]{18,64}");
    private final SharedPreferences prefs;

    PairingStore(Context context) {
        this.prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private SecretKey key() throws Exception {
        KeyStore keystore = KeyStore.getInstance("AndroidKeyStore");
        keystore.load(null);
        if (keystore.containsAlias(ALIAS)) {
            return (SecretKey) keystore.getKey(ALIAS, null);
        }
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build());
        return generator.generateKey();
    }

    @JavascriptInterface public synchronized boolean saveKey(String value) {
        if (value == null || !KEY_FORMAT.matcher(value).matches()) return false;
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key());
            byte[] iv = cipher.getIV();
            byte[] ciphertext = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
            byte[] packed = Arrays.copyOf(iv, iv.length + ciphertext.length);
            System.arraycopy(ciphertext, 0, packed, iv.length, ciphertext.length);
            return prefs.edit().putString(ENTRY, Base64.encodeToString(packed, Base64.NO_WRAP)).commit();
        } catch (Exception ex) {
            return false;
        }
    }

    @JavascriptInterface public synchronized String getKey() {
        String encoded = prefs.getString(ENTRY, null);
        if (encoded == null || encoded.isEmpty()) return "";
        try {
            byte[] packed = Base64.decode(encoded, Base64.NO_WRAP);
            if (packed.length < 12 + 16) return "";
            byte[] iv = Arrays.copyOfRange(packed, 0, 12);
            byte[] encrypted = Arrays.copyOfRange(packed, 12, packed.length);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
            String result = new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
            return KEY_FORMAT.matcher(result).matches() ? result : "";
        } catch (Exception ex) {
            return "";
        }
    }

    @JavascriptInterface public synchronized boolean clearKey() {
        return prefs.edit().remove(ENTRY).commit();
    }
}
