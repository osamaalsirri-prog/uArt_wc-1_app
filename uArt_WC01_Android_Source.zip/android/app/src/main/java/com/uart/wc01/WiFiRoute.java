package com.uart.wc01;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.RouteInfo;
import android.provider.Settings;
import android.webkit.JavascriptInterface;

import java.net.InetAddress;

/**
 * Does not request or change the handset's Wi-Fi credentials.
 * When user manually joins WC-01 AP (gateway 192.168.4.1), routes this app's
 * HTTP traffic over that Wi-Fi even if Android prefers cellular for Internet.
 */
public final class WiFiRoute {
    private final Activity activity;
    private final ConnectivityManager manager;
    private Network bound;
    private boolean registered = false;

    WiFiRoute(Activity activity) {
        this.activity = activity;
        this.manager = (ConnectivityManager) activity.getSystemService(Context.CONNECTIVITY_SERVICE);
    }

    private final ConnectivityManager.NetworkCallback callback = new ConnectivityManager.NetworkCallback() {
        @Override public void onAvailable(Network network) { refresh(); }
        @Override public void onLost(Network network) { refresh(); }
        @Override public void onLinkPropertiesChanged(Network network, LinkProperties properties) { refresh(); }
    };

    synchronized void onStart() {
        if (manager == null) return;
        if (!registered) {
            try {
                NetworkRequest request = new NetworkRequest.Builder()
                        .addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build();
                manager.registerNetworkCallback(request, callback);
                registered = true;
            } catch (Exception ignored) { /* App remains usable offline. */ }
        }
        refresh();
    }

    synchronized void onStop() {
        if (manager == null) return;
        if (registered) {
            try { manager.unregisterNetworkCallback(callback); } catch (Exception ignored) {}
            registered = false;
        }
        if (bound != null) {
            manager.bindProcessToNetwork(null);
            bound = null;
        }
    }

    synchronized void refresh() {
        if (manager == null || !registered) return;
        Network found = null;
        try {
            for (Network network : manager.getAllNetworks()) {
                NetworkCapabilities capabilities = manager.getNetworkCapabilities(network);
                if (capabilities == null || !capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) continue;
                LinkProperties properties = manager.getLinkProperties(network);
                if (!hasControllerGateway(properties)) continue;
                found = network;
                break;
            }
            if ((found == null ? bound != null : !found.equals(bound)) || !java.util.Objects.equals(found, manager.getBoundNetworkForProcess())) {
                if (!manager.bindProcessToNetwork(found)) return;
                bound = found;
                activity.runOnUiThread(() -> {
                    if (activity instanceof MainActivity) ((MainActivity) activity).notifyNetworkChanged();
                });
            }
        } catch (Exception ignored) { /* User may still connect manually. */ }
    }

    private boolean hasControllerGateway(LinkProperties properties) {
        if (properties == null) return false;
        for (RouteInfo route : properties.getRoutes()) {
            InetAddress gateway = route.getGateway();
            if (gateway != null && "192.168.4.1".equals(gateway.getHostAddress())) return true;
        }
        return false;
    }

    @JavascriptInterface public void openWifiSettings() {
        activity.runOnUiThread(() -> {
            try { activity.startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)); }
            catch (Exception ignored) {}
        });
    }

    @JavascriptInterface public void refreshRoute() { activity.runOnUiThread(this::refresh); }

    @JavascriptInterface public boolean isControllerNetwork() {
        synchronized (this) { return bound != null; }
    }
}
