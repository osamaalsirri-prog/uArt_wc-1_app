/* uArt WC-01 — persistent diagnostics archive v4.
   Native Android: each event is appended AND fsynced immediately into private JSONL files;
   rotation by local calendar day or 512 KiB. Export creates a ZIP through Android SAF.
   Browser preview: every event stored in IndexedDB; user chooses when to export JSONL.
   We never silently delete the on-disk archive from the UI.
*/
(function () {
  'use strict';
  const API = window.WC01NativeLogs;
  const native = Boolean(API && typeof API.appendRecord === 'function');
  const DB = 'uArt-WC01-Diagnostics-v3';
  let database = null, dbError = '', lastSaved = '', browserCount = 0;
  const dbReady = native ? Promise.resolve(null) : new Promise(resolve => {
    if (!('indexedDB' in window)) { dbError = 'IndexedDB is not available'; resolve(null); return; }
    try {
      const request = indexedDB.open(DB, 1);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains('events')) {
          const store = db.createObjectStore('events', {keyPath:'id', autoIncrement:true});
          store.createIndex('time','time',{unique:false});
        }
      };
      request.onsuccess = () => {
        database = request.result;
        const t = database.transaction('events','readonly');
        const count = t.objectStore('events').count();
        count.onsuccess = () => { browserCount = count.result || 0; };
        resolve(database);
      };
      request.onerror = () => { dbError = 'Archive storage blocked by browser'; resolve(null); };
      request.onblocked = () => { dbError = 'Archive database blocked by another tab'; resolve(null); };
    } catch (e) { dbError = String(e.message||e); resolve(null); }
  });
  const safe = record => ({
    time: String(record.time || new Date().toISOString()).slice(0,40),
    level: ['info','warn','error'].includes(record.level) ? record.level : 'info',
    text: String(record.text||'').slice(0,500),
    mode: record.mode === 'live' ? 'live' : 'demo',
    source:'uArt WC-01 app',
    version:'4.1.0'
  });
  function append(input) {
    const record = safe(input);
    if (native) {
      try {
        const result = API.appendRecord(JSON.stringify(record));
        if (result) { lastSaved = record.time; return Promise.resolve(true); }
        return Promise.resolve(false);
      } catch (e) { dbError = String(e.message || e); return Promise.resolve(false); }
    }
    return dbReady.then(db => new Promise(resolve => {
      if (!db) { resolve(false); return; }
      try {
        const request = db.transaction('events','readwrite').objectStore('events').add(record);
        request.onsuccess = () => { browserCount++; lastSaved = record.time; resolve(true); };
        request.onerror = () => { dbError = 'Could not save event to IndexedDB'; resolve(false); };
      } catch (e) { dbError = String(e.message || e); resolve(false); }
    }));
  }
  async function status() {
    if (native) {
      try {
        const s = JSON.parse(API.getArchiveStats());
        return {native:true, files:s.files || 0, entries:s.entries || null,
          bytes:s.bytes || 0, last:s.last || null, error:s.error||''};
      } catch (e) { return {native:true,files:0,bytes:0,last:null,error:String(e.message||e)}; }
    }
    await dbReady;
    return {native:false,files:database?1:0, entries:browserCount, bytes:0,last:lastSaved,error:dbError};
  }
  async function exportArchive() {
    if (native) {
      try { API.exportArchive();return true; } catch(e) { dbError=String(e.message||e); return false; }
    }
    const db = await dbReady;
    if (!db) return false;
    return await new Promise(resolve => {
      const entries=[];
      try {
        const req=db.transaction('events','readonly').objectStore('events').openCursor();
        req.onsuccess=() => {
          const c=req.result;
          if(c) { const {id,...value}=c.value;entries.push(JSON.stringify(value));c.continue();return; }
          const blob=new Blob([entries.join('\n')+(entries.length?'\n':'')],{type:'application/x-ndjson'});
          const a=document.createElement('a');const url=URL.createObjectURL(blob);
          a.href=url;a.download='uArt_WC01_Diagnostics_'+new Date().toISOString().slice(0,10)+'.jsonl';
          a.style.display='none';document.body.append(a);a.click();a.remove();
          setTimeout(()=>URL.revokeObjectURL(url),10000);resolve(true);
        };
        req.onerror=()=>resolve(false);
      } catch(e) {dbError=String(e.message||e);resolve(false);}
    });
  }
  window.WC01LogArchive = Object.freeze({append,status,exportArchive,isNative:native});
})();
