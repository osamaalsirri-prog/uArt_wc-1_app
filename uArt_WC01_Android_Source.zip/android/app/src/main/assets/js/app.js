/* uArt WC-01 v5 | Android LIVE application, no simulated machine state.
   Original logo unchanged. Physical controller is authoritative for all operations. */
(() => {'use strict';
const $=id=>document.getElementById(id), $$=s=>[...document.querySelectorAll(s)];
const get=(k,f)=>{try{let d=localStorage.getItem('uart-v5-'+k);if(d===null&&['lang','machine','programs','events'].includes(k))d=localStorage.getItem('uart2-'+k);return d===null?f:JSON.parse(d)}catch{return f}};
const put=(k,v)=>{try{localStorage.setItem('uart-v5-'+k,JSON.stringify(v))}catch{}};
const LEGAL_COMPANY='uArt',LEGAL_FOUNDER='OSAMA SHARIF AL-SIRRI',PRODUCT_MODEL='WC-01';
let language=get('lang','en')==='ar'?'ar':'en';let connection='disconnected',apiBase='http://192.168.4.1',authorization='',liveStatus={},cap={},firmware='—';
// The handset joins Wi-Fi in Android Settings. This app NEVER manages Wi-Fi credentials.
// WC01Pairing stores the independent application authorization key encrypted with Android Keystore.
const pairBridge=window.WC01Pairing||null;
const wifiBridge=window.WC01Network||null;
let previewPairKey='',reconnectBusy=false,authRejected=false,reconnectTimer=null,linkError='',pairingDialogUsed=false;
function readPairedKey(){try{return pairBridge?String(pairBridge.getKey()||''):previewPairKey}catch{return ''}}
function storePairedKey(key){try{if(pairBridge)return pairBridge.saveKey(key)===true;previewPairKey=key;return true}catch{return false}}
function clearPairedKey(){try{if(pairBridge)return pairBridge.clearKey()===true;previewPairKey='';return true}catch{return false}}
function openPhoneWiFi(){if(wifiBridge){try{wifiBridge.openWifiSettings();return}catch{}}notify(msg('Open your phone Wi-Fi settings and join uArt-WC01.','افتح إعدادات واي فاي الموبايل واتصل بشبكة uArt-WC01.'))}
function showPairing(){const el=$('pairOverlay');if(!el)return;pairingDialogUsed=true;el.classList.remove('hidden');document.body.style.overflow='hidden';$('initialPairKey').value='';$('initialPairKey').type='password'}
function hidePairing(){const el=$('pairOverlay');if(el)el.classList.add('hidden');if(!$$('.overlay:not(.hidden)').length)document.body.style.overflow=''}
function pairOnce(){const key=$('initialPairKey').value.trim();if(!/^[A-Za-z0-9]{18,64}$/.test(key)){notify(msg('Enter the complete Pair Key shown on the controller (18–64 characters).','اكتب مفتاح App Pair Key كاملًا من شاشة الكنترول (18–64 حرفًا أو رقمًا).'));return}
 if(!storePairedKey(key)){notify(msg('Unable to store pairing key securely.','تعذر حفظ مفتاح الربط بأمان.'));return}
 commandGeneration++;statusGeneration++;stopJog();clearInterval(pollTimer);pollTimer=null;authorization='';connection='disconnected';cap={};liveStatus={};authRejected=false;hidePairing();render();logEvent('Pairing key saved on phone');connect();}

let stopPending=false,commandBusy=false,commandGeneration=0,statusGeneration=0,jogGeneration=0;
let jogEpoch=1,lastValid=0,pollBusy=false,pollTimer=null,jogTimer=null,holdDir=0,fastEnabled=false,toastTimer=null,archiveRefreshTimeout=null;
let pendingConfirm=null,currentPage='home',draftType=0;const mode='live';
const defaults={speed:120,distance:250,pulse:3,pulseEnabled:true,initial:30,jog:50,fast:600,lead:10,sleep:5,direction:0,weldingType:0,autoReturn:true};
let config={...defaults,...get('draft',{})};
const data=get('machine',{});let info={serial:String(data.serial||'').slice(0,50),nominalLength:Number(data.nominalLength)||1000,usableTravel:Number(data.usableTravel)||null};
let presets=get('programs',[]);if(!Array.isArray(presets))presets=[];
let logs=get('events',[]);if(!Array.isArray(logs))logs=[];logs=logs.slice(0,100);
const langMap={
 en:{openPhoneWifi:'Phone Wi-Fi settings',changePairKey:'Change Pair Key',pairOnceTitle:'Pair this phone once',pairOnceInfo:'Join uArt-WC01 from Android Wi-Fi settings. Enter the App Pair Key shown on the controller just once; it is saved securely.',pairSaveAndGo:'Save key & control',skip:'Skip intro',getStarted:'Get started',main:'Main',motion:'Motion',settings:'Settings',programs:'Programs',machine:'Machine',connectionDetails:'Connection & controller details',jobSetup:'JOB SETUP',weldingType:'Welding mode',weldSpeed:'Weld speed',travelDistance:'Travel distance',pulseRate:'Relay frequency',direction:'Direction',travelMonitoring:'TRAVEL MONITORING',currentRun:'Current run',position:'Position',progress:'Progress',positionNote:'Position is estimated from issued motor steps, not measured by an encoder.',runControls:'RUN CONTROLS',operation:'Operation',start:'START',pause:'PAUSE',resume:'RESUME',stop:'STOP',returnHome:'Return HOME',goMotion:'Manual movement',demoWarning:'Live ESP32 data only. Unsupported actions are locked until commissioning.',motionCaption:'Hold a direction to jog; release to stop. Movement is blocked while welding.',manualJog:'MANUAL JOG',axis1:'Linear axis',usableTravel:'Calibrated travel',holdToMove:'Press and hold to move · Release to stop',backward:'Backward',forward:'Forward',safetyRules:'Movement interlock',safetyBody:'During welding, manual motion is blocked. Physical limits, independent emergency stop, and communication watchdog are required before real movement.',settingsCaption:'Review process values before applying them. A local save is not a controller update.',weldingSettings:'Welding parameters',motionSettings:'Motion parameters',machineOptions:'Machine options',initialSpeed:'Initial approach speed',manualSpeed:'Manual jog speed',fastSpeed:'FAST speed',screwLead:'Screw lead',displaySleep:'Screen timeout',pulseEnable:'Pulse mode',pulseNote:'0 Hz means continuous output only if welder output is commissioned.',autoReturn:'Auto-return after completion',returnNotice:'Only after a normal job ends; requires verified motion limits.',saveSettings:'SAVE SETTINGS',programsCaption:'Save complete process setups on this device and recall them later.',savePreset:'Save current settings',presetName:'Program name',savePresetButton:'SAVE PROGRAM',yourPrograms:'YOUR LIBRARY',savedPrograms:'Saved programs',machineCaption:'Connection, diagnostics, controller capabilities and machine identity.',operatingMode:'OPERATING MODE',wifiConnection:'ESP32 connection',wifiGuide:'Join uArt-WC01 in Android Wi-Fi settings. The app connects automatically and uses the saved Pair Key.',pairingKey:'Pairing key',connect:'CONNECT',disconnect:'Disconnect',useDemo:'',controllerCapabilities:'Controller capabilities',monitor:'Monitoring',motorControl:'Motor control',home:'HOME',remoteStart:'Remote START',safetyInputs:'Safety inputs & homing',homeSensor:'HOME sensor',endSensor:'END sensor',estop:'Emergency stop input',homing:'Position homed',diagNote:'Displayed diagnostics do not replace hardwired safety.',machineInformation:'Machine information & about',viewDetails:'Manufacturer, model, founder and hardware',activity:'Activity & diagnostics',clear:'Clear',aboutTitle:'About this machine',founder:'FOUNDER & COMPANY OWNER',manufacturer:'Manufacturer',model:'Model',serialNumber:'Serial number',nominalLength:'Nominal rail length',controller:'Controller',motorDriver:'Motor driver',firmware:'Firmware',editMachineData:'Edit machine data',machineDataNote:'Identification data is saved on this phone only. It does not change hardware travel limits.',save:'SAVE',cancel:'Cancel',confirm:'Confirm',lockedBrand:'Official company name · read-only',autoArchive:'Every event is archived automatically',archiveFiles:'Archive files',archiveSize:'Archive size',archiveLast:'Last saved',exportArchive:'Export diagnostics',clearView:'Clear display'},
 ar:{openPhoneWifi:'إعدادات واي فاي الموبايل',changePairKey:'تغيير مفتاح الربط',pairOnceTitle:'ربط الموبايل أول مرة',pairOnceInfo:'اتصل بشبكة uArt-WC01 من إعدادات الواي فاي العادية، واكتب مفتاح App Pair Key الظاهر في شاشة الكنترول مرة واحدة بس. هيتحفظ بأمان.',pairSaveAndGo:'حفظ المفتاح والدخول للتحكم',skip:'تخطي المقدمة',getStarted:'ابدأ الآن',main:'الرئيسية',motion:'الحركة',settings:'الإعدادات',programs:'البرامج',machine:'الماكينة',connectionDetails:'الاتصال ومعلومات الكنترول',jobSetup:'إعداد التشغيل',weldingType:'نوع اللحام',weldSpeed:'سرعة اللحام',travelDistance:'مسافة الحركة',pulseRate:'تردد الريلاي',direction:'الاتجاه',travelMonitoring:'مراقبة الحركة',currentRun:'التشغيل الحالي',position:'الموقع',progress:'الإنجاز',positionNote:'الموضع محسوب من نبضات الموتور وقد يختلف عن الموضع الفعلي لو فقد خطوات.',runControls:'التحكم في التشغيل',operation:'التشغيل',start:'ابدأ',pause:'إيقاف مؤقت',resume:'استكمال',stop:'إيقاف',returnHome:'الرجوع للأصل',goMotion:'الحركة اليدوية',demoWarning:'البيانات من الكنترول الحقيقي فقط. الوظائف غير المعتمدة مقفولة.',motionCaption:'اضغط باستمرار للتحريك واترك الزر للتوقف. الحركة ممنوعة أثناء اللحام.',manualJog:'التحريك اليدوي',axis1:'المحور الخطي',usableTravel:'المشوار المُعاير',holdToMove:'اضغط باستمرار للتحريك • اترك الزر للتوقف',backward:'خلف',forward:'أمام',safetyRules:'تأمين الحركة',safetyBody:'الحركة اليدوية ممنوعة أثناء اللحام. يلزم حساسات حدود وفصل طوارئ مستقل ومراقبة اتصال بالكنترول قبل التشغيل الحقيقي.',settingsCaption:'راجع إعدادات التشغيل قبل التطبيق؛ الحفظ على الهاتف ليس إرسالًا للكنترول.',weldingSettings:'إعدادات اللحام',motionSettings:'إعدادات الحركة',machineOptions:'خيارات الماكينة',initialSpeed:'سرعة البداية',manualSpeed:'سرعة التحريك اليدوي',fastSpeed:'السرعة السريعة FAST',screwLead:'مشوار الاسكرو لكل لفة',displaySleep:'إطفاء الشاشة بعد',pulseEnable:'وضع النبضات',pulseNote:'0 هرتز يعني خرج مستمر فقط بعد اعتماد وتفعيل خرج اللحام.',autoReturn:'رجوع تلقائي بعد الاكتمال',returnNotice:'بعد نهاية طبيعية فقط، ويتطلب حدود حركة مؤمّنة.',saveSettings:'حفظ الإعدادات',programsCaption:'احفظ إعدادات اللحام الكاملة على الهاتف واستدعها لاحقًا.',savePreset:'حفظ الإعدادات الحالية',presetName:'اسم البرنامج',savePresetButton:'حفظ البرنامج',yourPrograms:'مكتبة البرامج',savedPrograms:'البرامج المحفوظة',machineCaption:'الاتصال والتشخيص وإمكانات الكنترول وبيانات الماكينة.',operatingMode:'وضع التشغيل',wifiConnection:'اتصال ESP32',wifiGuide:'اتصل بشبكة uArt-WC01 من إعدادات واي فاي الموبايل. التطبيق هيتصل تلقائيًا بمفتاح الربط المحفوظ.',pairingKey:'مفتاح الربط',connect:'اتصال',disconnect:'فصل',useDemo:'',controllerCapabilities:'إمكانات الكنترول',monitor:'المراقبة',motorControl:'التحكم في الموتور',home:'الرجوع للأصل',remoteStart:'التشغيل عن بعد',safetyInputs:'الحساسات والأمان',homeSensor:'حساس البداية HOME',endSensor:'حساس النهاية END',estop:'فصل الطوارئ',homing:'تمت المعايرة والرجوع',diagNote:'عرض الحساسات لا يغني عن دائرة أمان مستقلة.',machineInformation:'معلومات الماكينة والتطبيق',viewDetails:'الشركة والموديل والمؤسس والمكونات',activity:'سجل الأحداث والتشخيص',clear:'مسح',aboutTitle:'معلومات الماكينة والتطبيق',founder:'مؤسس الشركة ومالكها',manufacturer:'الشركة المصنعة',model:'الموديل',serialNumber:'الرقم التسلسلي',nominalLength:'طول السكة الاسمي',controller:'المتحكم',motorDriver:'درايفر الموتور',firmware:'إصدار الكنترول',editMachineData:'تعديل بيانات الماكينة',machineDataNote:'البيانات تتحفظ في الهاتف فقط ولا تغيّر حدود حركة الماكينة.',save:'حفظ',cancel:'إلغاء',confirm:'تأكيد',lockedBrand:'اسم الشركة الرسمي · للقراءة فقط',autoArchive:'يُحفظ كل حدث في الأرشيف تلقائيًا',archiveFiles:'ملفات السجل',archiveSize:'حجم الأرشيف',archiveLast:'آخر حفظ',exportArchive:'تصدير سجل التشخيص',clearView:'مسح العرض'},
};
const tx=k=>langMap[language][k]||k;
const msg=(en,ar)=>language==='ar'?ar:en;
function notify(text){const e=$('toast');e.textContent=text;e.classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>e.classList.remove('visible'),3700)}
function logEvent(text,level='info'){
 const safeText=String(text).replace(/(key|token|password|secret)\s*[:=]\s*[^,\s]+/gi,'$1=[REDACTED]').slice(0,500);
 const record={time:new Date().toISOString(),text:safeText,level,mode};
 logs.unshift(record);logs=logs.slice(0,100);put('events',logs);renderEvents();
 WC01LogArchive.append(record).then(ok=>{if(!ok){$('logRecordingState').textContent=msg('Archive write failed — export or check storage','فشل حفظ الأرشيف — افحص مساحة التخزين');$('logRecordingState').classList.add('archive-error');document.querySelector('.archive-led')?.classList.add('archive-error-led');} scheduleArchiveRefresh();});
}
function scheduleArchiveRefresh(){clearTimeout(archiveRefreshTimeout);archiveRefreshTimeout=setTimeout(refreshArchive,220)}
async function refreshArchive(){
 const s=await WC01LogArchive.status();
 $('archiveCount').textContent=s.native?String(s.files):msg('Browser database','تخزين المتصفح');
 $('archiveSize').textContent=s.native?(s.bytes<1024?'0 KB':(s.bytes/1024/1024).toFixed(2)+' MB'):(s.entries??0)+' '+msg('events','حدث');
 $('archiveLast').textContent=s.last?new Date(s.last).toLocaleString(language==='ar'?'ar-EG':'en-GB',{month:'short',day:'2-digit',hour:'2-digit',minute:'2-digit'}):'—';
 $('archiveNote').textContent=s.native?msg('Android: every event is written immediately to private JSONL files. New file each day or every 512 KB. Export ZIP to keep an external copy. Clearing the display does NOT erase archived files.','أندرويد: كل حدث يتحفظ فورًا في ملفات JSONL خاصة بالتطبيق. ملف جديد كل يوم أو كل 512 كيلوبايت. تقدر تصدّر ZIP؛ مسح الشاشة لا يمسح الأرشيف.'):msg('Browser preview: records are saved locally in IndexedDB. Export JSONL manually to keep a file.','معاينة المتصفح: الأحداث محفوظة في IndexedDB محليًا، ويمكن تصدير ملف JSONL يدويًا.');
 if(s.error){$('logRecordingState').textContent=msg('ARCHIVE ERROR: ','خطأ في الأرشيف: ')+s.error;$('logRecordingState').classList.add('archive-error');document.querySelector('.archive-led')?.classList.add('archive-error-led')}
 else {$('logRecordingState').textContent=tx('autoArchive');$('logRecordingState').classList.remove('archive-error');document.querySelector('.archive-led')?.classList.remove('archive-error-led')}
}

function renderEvents(){const root=$('eventList');if(!root)return;root.replaceChildren();if(!logs.length){const e=document.createElement('p');e.className='muted-para';e.textContent=msg('No events recorded yet.','لا توجد أحداث مسجلة.');root.append(e);return}for(const v of logs){const row=document.createElement('div'),time=document.createElement('time'),message=document.createElement('span');row.className='event-entry';time.textContent=new Date(v.time).toLocaleString(language==='ar'?'ar-EG':'en-GB',{month:'short',day:'2-digit',hour:'2-digit',minute:'2-digit'});message.textContent=v.text;if(v.level==='warn')message.classList.add('event-sev');row.append(time,message);root.append(row)}}
function safeText(v){return String(v??'').slice(0,120)}
function setLanguage(v){language=v==='ar'?'ar':'en';put('lang',language);
 document.documentElement.lang=language;document.documentElement.dir=language==='ar'?'rtl':'ltr';
 $$('[data-i18n]').forEach(e=>{if(e.id!=='demoModeBtn')e.textContent=tx(e.dataset.i18n)});
 $('langBtn').textContent=language==='en'?'AR':'EN';
 $('fDirection').options[0].textContent=msg('Forward','أمام');$('fDirection').options[1].textContent=msg('Backward','خلف');
 render();renderEvents();refreshArchive();}
function go(tab){stopJog();panelPointers.clear();tab=String(tab);currentPage=tab;
 $$('.screen').forEach(el=>el.classList.toggle('active',el.id==='page-'+tab));
 $$('[data-go]').forEach(el=>{const selected=el.dataset.go===tab;el.classList.toggle('active',selected);if(selected)el.setAttribute('aria-current','page');else el.removeAttribute('aria-current')});
 if(tab==='settings')fillForm();if(tab==='programs')renderPrograms();if(tab==='machine'){renderEvents();refreshArchive()}
 window.scrollTo(0,0);render();}
function online(){return connection==='connected'}
function allowJog(){return online()&&!commandBusy&&!stopPending&&cap.jog===true&&liveStatus.backlight_on!==false&&(liveStatus.state==='ready'||liveStatus.state==='paused')}
function stateText(){if(connection==='lost')return msg('LINK LOST','انقطع الاتصال');if(connection==='connecting')return msg('CONNECTING','جاري الاتصال');if(!online())return msg('DISCONNECTED','غير متصل');
 const states={ready:'READY',idle:'IDLE',preview_locked:'PREVIEW LOCKED',alarm_screen:'ALARM SCREEN',running:'RUNNING',paused:'PAUSED'};
 return states[liveStatus.state]||String(liveStatus.state||'CONNECTED').toUpperCase();}
let liveSpeedDraft=false;
function numericField(value){return value!==null&&value!==undefined&&value!==''&&(typeof value==='number'||typeof value==='string')&&Number.isFinite(Number(value))?Number(value):null}
function canLiveSpeed(d){return d.state==='running'&&d.homed===true&&!d.home_skipped&&!d.fault_code&&d.cap?.travel_limited===true}

const PANEL_BITS={start:0,enter:1,pause:2,esc:3,fast:4,up:5,down:6};
let floatingOpen=false,panelDrag=null,panelSuppressClick=false;
const panelPointers=new Map();
function panelHas(key,d=liveStatus){return d.panel_keys===true&&Number.isInteger(d.panel_nav)&&!!(d.panel_nav&(1<<PANEL_BITS[key]))}
function panelReady(){return online()&&!commandBusy&&!stopPending}
function panelWake(){return panelReady()&&liveStatus.panel_keys===true&&liveStatus.backlight_on===false}
function panelAllowed(k){
 if(!online())return false;
 if(k==='start'&&['running','homing'].includes(liveStatus.state))return true;
 if(!panelReady())return false;
 if(panelWake())return true;
 if(k==='start')return cap.start===true||liveStatus.state==='paused'||panelHas(k);
 if(k==='pause')return ['running','paused','homing'].includes(liveStatus.state);
 if(k==='enter'&&(liveStatus.state==='home_required'&&cap.home===true||liveStatus.state==='paused'))return true;
 if(k==='esc'&&liveStatus.state==='homing')return true;
 if(['up','down','fast'].includes(k)&&allowJog())return true;
 return panelHas(k);
}
function renderFloatingPanel(){
 $('panelFab').classList.toggle('connected',online());
 $('panelFab').setAttribute('aria-label',msg('Floating control panel','أزرار الطبلون العائمة'));
 $('panelTitle').textContent=msg('Panel buttons','أزرار الطبلون');
 $('panelClose').setAttribute('aria-label',msg('Close panel','إغلاق الطبلون'));
 $('panelState').textContent=stateText();
 const pos=online()&&liveStatus.homed===true&&!liveStatus.home_skipped?numericField(liveStatus.position_mm):null;
 $('panelPosition').textContent=pos===null?'—':pos.toFixed(2)+' mm';
 for(const k of Object.keys(PANEL_BITS))$('panel-'+k).disabled=!panelAllowed(k);
 $('panel-fast').classList.toggle('active',fastEnabled&&allowJog());
 $('panel-fast').setAttribute('aria-pressed',String(fastEnabled&&allowJog()));
 $('panel-up').classList.toggle('holding',holdDir===1);
 $('panel-down').classList.toggle('holding',holdDir===-1);
 $('panel-pause').querySelector('b').textContent=liveStatus.state==='paused'?'RESUME':'PAUSE';
 const labels={start:liveStatus.state==='running'?msg('Stop cycle','إيقاف الدورة'):liveStatus.state==='paused'?msg('Resume','استكمال'):msg('Start','تشغيل'),pause:liveStatus.state==='paused'?msg('Resume','استكمال'):msg('Pause','إيقاف مؤقت'),enter:msg('Select','تأكيد'),esc:msg('Back','رجوع'),fast:allowJog()?(fastEnabled?'ON':'OFF'):msg('Ready','جاهز'),up:allowJog()?msg('Toward HOME','ناحية HOME'):msg('Up / +','أعلى / +'),down:allowJog()?msg('Toward END','ناحية END'):msg('Down / −','أسفل / −')};
 for(const [k,label] of Object.entries(labels))$('panel-sub-'+k).textContent=label;
 $('panelHint').textContent=!online()?msg('Connect to the controller. No commands are queued.','اتصل بالكنترول؛ لا تُحفظ أوامر للتنفيذ لاحقًا.'):panelWake()?msg('First key wakes the controller display only.','أول ضغطة توقظ شاشة الكنترول فقط.'):liveStatus.panel_keys!==true?msg('Controller v7.3.10 needed for menu keys. Motion remains interlocked.','التنقل في القوائم يحتاج كنترول V7.3.10؛ الحركة محمية.'):msg('Hold UP/DOWN to jog only in READY or PAUSED; release to stop. Calibration and fault recovery are local only.','اضغط UP/DOWN باستمرار للحركة في READY أو PAUSE واترك للإيقاف. المعايرة ومعالجة الأعطال من الطبلون فقط.');
}
function toggleFloatingPanel(open=!floatingOpen){
 floatingOpen=!!open;
 if(!floatingOpen){panelPointers.clear();stopJog();}
 $('floatingPanel').classList.toggle('hidden',!floatingOpen);
 $('panelFab').setAttribute('aria-expanded',String(floatingOpen));
 renderFloatingPanel();
}
function panelNav(k){
 if(!panelReady()||(!panelHas(k)&&k!=='wake'))return;
 sendCommand('panel_key',{key:k,page:String(liveStatus.page),selection:String(liveStatus.panel_selection)});
}
function panelResume(){
 confirmAction(msg('Confirm RESUME','تأكيد استكمال اللحام'),msg('Check the clear travel path and physical safety controls.','اتأكد من خلو المسار ووسائل الأمان الفعلية.'),()=>{if(liveStatus.state==='paused')sendCommand('resume');else notify(msg('Controller state changed.','حالة الكنترول تغيرت.'))});
}
function panelPress(k){
 if(!panelAllowed(k))return;
 if(k==='start'&&['running','homing'].includes(liveStatus.state)){actStop();return}
 if(panelWake()){panelNav('wake');return}
 if(k==='start'){if(liveStatus.state==='paused')panelResume();else if(panelHas(k))panelNav(k);else actStart();return}
 if(k==='pause'){if(liveStatus.state==='paused')panelResume();else sendCommand('pause');return}
 if(k==='enter'){if(liveStatus.state==='home_required'&&cap.home)actHome();else if(liveStatus.state==='paused')panelResume();else panelNav(k);return}
 if(k==='esc'&&liveStatus.state==='homing'){actStop();return}
 if(k==='fast'&&allowJog()){setFast();return}
 panelNav(k);
}
function panelFabPosition(x,y,save=false){
 const el=$('panelFab'),w=el.offsetWidth||58,h=el.offsetHeight||58;
 const minX=6,maxX=Math.max(minX,innerWidth-w-6),minY=8,maxY=Math.max(minY,innerHeight-h-100);
 x=Math.min(maxX,Math.max(minX,x));y=Math.min(maxY,Math.max(minY,y));
 el.style.left=x+'px';el.style.top=y+'px';el.style.right='auto';
 if(save)put('panelFabPosition',{x:(x-minX)/Math.max(1,maxX-minX),y:(y-minY)/Math.max(1,maxY-minY)});
}
function restorePanelFab(){
 const q=get('panelFabPosition',{x:1,y:.45}),w=$('panelFab').offsetWidth||58,h=$('panelFab').offsetHeight||58;
 panelFabPosition(6+(innerWidth-w-12)*Math.min(1,Math.max(0,Number(q.x)||0)),8+Math.max(0,innerHeight-h-108)*Math.min(1,Math.max(0,Number(q.y)||0)));
}
function bindFloatingPanel(){
 const fab=$('panelFab');
 fab.addEventListener('pointerdown',e=>{if(e.button!==0)return;const r=fab.getBoundingClientRect();panelDrag={id:e.pointerId,x:e.clientX,y:e.clientY,l:r.left,t:r.top,moved:false};panelSuppressClick=false;try{fab.setPointerCapture(e.pointerId)}catch{}});
 fab.addEventListener('pointermove',e=>{if(!panelDrag||panelDrag.id!==e.pointerId)return;let dx=e.clientX-panelDrag.x,dy=e.clientY-panelDrag.y;if(Math.hypot(dx,dy)>7)panelDrag.moved=true;if(panelDrag.moved){e.preventDefault();panelFabPosition(panelDrag.l+dx,panelDrag.t+dy)}});
 function endDrag(e){if(!panelDrag||panelDrag.id!==e.pointerId)return;const d=panelDrag;panelDrag=null;panelSuppressClick=d.moved||e.type!=='pointerup';if(d.moved){const r=fab.getBoundingClientRect();panelFabPosition(r.left+r.width/2<innerWidth/2?6:innerWidth-r.width-6,r.top,true)}}
 for(const event of ['pointerup','pointercancel','lostpointercapture'])fab.addEventListener(event,endDrag);
 fab.addEventListener('click',()=>{if(panelSuppressClick){panelSuppressClick=false;return}toggleFloatingPanel()});
 fab.addEventListener('contextmenu',e=>e.preventDefault());
 $('panelClose').onclick=()=>toggleFloatingPanel(false);
 for(const k of ['start','pause','enter','esc','fast'])$('panel-'+k).onclick=()=>panelPress(k);
 for(const [k,dir] of [['up',1],['down',-1]]){
  const el=$('panel-'+k);
  el.addEventListener('pointerdown',e=>{if(el.disabled||e.button!==0)return;e.preventDefault();if(panelPointers.size){panelPointers.set(e.pointerId,dir);stopJog();renderFloatingPanel();return}panelPointers.set(e.pointerId,dir);try{el.setPointerCapture(e.pointerId)}catch{}if(allowJog()&&!panelWake()){startJog(dir,e);renderFloatingPanel()}else panelPress(k)});
  const release=e=>{if(!panelPointers.has(e.pointerId))return;panelPointers.delete(e.pointerId);releaseJog(dir);renderFloatingPanel()};
  for(const event of ['pointerup','pointercancel','lostpointercapture','pointerleave'])el.addEventListener(event,release);
  el.addEventListener('click',e=>{if(e.detail===0&&!allowJog())panelPress(k)});
  el.addEventListener('contextmenu',e=>e.preventDefault());
 }
 window.addEventListener('resize',restorePanelFab);
 window.addEventListener('blur',()=>{panelPointers.clear();stopJog()});
 document.addEventListener('visibilitychange',()=>{if(document.hidden){panelPointers.clear();stopJog()}});
}

function render(){
 renderFloatingPanel();
 const status=stateText();const bad=connection==='lost';
 $('connectionTitle').textContent=online()?msg('ESP32 connected','متصل بالكنترول'):bad?msg('Connection lost','انقطع الاتصال'):msg('ESP32 disconnected','الكنترول غير متصل');
 $('connDetail').textContent=online()?'ESP32 | '+firmware:connection==='connecting'?msg('Connecting automatically…','جاري الاتصال تلقائيًا…'):authRejected?msg('Check controller App Pair Key','راجع مفتاح الربط App Pair Key'):msg('Join uArt-WC01 in Android Wi-Fi settings','اتصل بشبكة uArt-WC01 من إعدادات الموبايل');
 $('statePill').textContent=status;$('wifiChip').textContent=online()?'ONLINE':(bad?'LOST':'OFFLINE');
 for(const name of ['statePill','wifiChip'])$(name).className='state-pill'+(online()?' online':bad?' unknown':'');
 $('statusDot').className='status-dot'+(online()?' online':bad?' unknown':'');
 $('modeSummary').textContent=online()?msg('Connected to ESP32','متصل بالكنترول'):msg('Offline','غير متصل');
 $('modeDescription').textContent=online()?firmware:msg('No hardware values are being reported','لا توجد قراءات حقيقية من الماكينة');
 $('firmwareBrief').textContent=online()?firmware:'NOT VERIFIED';
 const v=(field,digits=0)=>online()&&liveStatus[field]!==null&&liveStatus[field]!==undefined&&Number.isFinite(Number(liveStatus[field]))?Number(liveStatus[field]).toFixed(digits):'—';
 $('metricSpeed').textContent=v('speed',0);$('metricDistance').textContent=v('distance',0);
 $('metricPulse').textContent=v('pulse',1);$('pulseUnit').textContent='Hz';
 $('metricDirection').textContent=online()?(Number(liveStatus.direction)?msg('Backward','خلف'):msg('Forward','أمام')):'—';
 const wt=online()?Number(liveStatus.welding_type):null;
 $('btnTIG').classList.toggle('active',wt===0);$('btnCO2').classList.toggle('active',wt===1);
 const reportedPos=online()&&liveStatus.homed===true?numericField(liveStatus.position_mm):null;
 const pos=reportedPos!==null&&!liveStatus.home_skipped?reportedPos:null;
 const traveled=online()?numericField(liveStatus.traveled):null;
 $('cycleTravel').textContent=traveled===null?'—':traveled.toFixed(2)+' mm';
 const speed=online()?numericField(liveStatus.speed_mm_s):null;
 const speedAllowed=online()&&!commandBusy&&!stopPending&&canLiveSpeed(liveStatus);
 $('liveSpeedTitle').textContent=msg('Live welding speed','سرعة اللحام أثناء التشغيل');
 $('liveSpeedApply').textContent=msg('Apply speed','تطبيق السرعة');
 $('liveSpeedHelp').textContent=speedAllowed?msg('Change setpoint without stopping the weld.','غيّر السرعة دون إيقاف اللحام.'):msg('Available only during active welding; other settings stay locked.','متاح أثناء اللحام الفعلي فقط؛ باقي الإعدادات تظل مقفولة.');
 $('liveSpeedNow').textContent=speed===null?'—':speed.toFixed(2)+' mm/s';
 for(const id of ['liveSpeedInput','liveSpeedMinus','liveSpeedPlus','liveSpeedApply'])$(id).disabled=!speedAllowed;
 if(!speedAllowed&&!commandBusy)liveSpeedDraft=false;
 if(!liveSpeedDraft&&document.activeElement!==$('liveSpeedInput'))$('liveSpeedInput').value=speed===null?'':speed.toFixed(2);
 $('posValue').textContent=pos===null?'—':pos.toFixed(1)+' mm';
 $('jogPos').textContent=pos===null?msg('Not referenced','غير مُعاير HOME'):pos.toFixed(2)+' mm';
 $('posValue').textContent=pos===null?'—':pos.toFixed(2)+' mm';
 const pct=online()&&typeof liveStatus.progress==='number'&&Number.isFinite(liveStatus.progress)?Math.max(0,Math.min(100,liveStatus.progress)):null;
 $('progressValue').textContent=pct===null?'—':pct.toFixed(0)+' %';
 $('progressFill').style.width=pct===null?'0%':pct+'%';
 $('positionSource').textContent=pos===null?'NOT REFERENCED':'STEP COUNT ESTIMATE';
 $('travelHint').textContent=pos===null?msg('Position not reported by the controller. Never assume 0 mm.','الكنترول لم يؤكد الموضع؛ لا نفترض إنه صفر مم.'):msg('Position reported by controller.','الموضع مرسل من الكنترول.');
 const rawTravel=online()?numericField(liveStatus.travel_limit_mm):null;
 const travel=rawTravel!==null&&rawTravel>5?rawTravel:null;
 const known=pos!==null&&travel!==null&&pos>=0&&pos<=travel;
 const moving=online()&&(liveStatus.motor_jogging===true||liveStatus.state==='running'||liveStatus.state==='homing');
 let positionNote=!online()?msg('No live connection.','لا يوجد اتصال مباشر.'):liveStatus.home_skipped?msg('Manual zero only; real HOME required for absolute position.','الصفر يدوي فقط؛ نفّذ HOME الحقيقي لتحديد مكان الرأس.'):pos===null?msg('Position not reported; complete real HOME.','الكنترول لا يرسل موضعًا مرجعيًا؛ نفّذ HOME الحقيقي.'):travel===null?msg('Set measured Travel Limit to plot the rail.','اضبط المشوار المقاس لعرض الرأس على السكة.'):!known?msg('Position outside reported travel; inspect controller.','الموضع خارج المشوار المرسل؛ راجع الكنترول.'):msg('HOME on right · estimated from actual STEP count','HOME على اليمين · تقدير من عدّ نبضات STEP');
 for(const [markerId,labelId,limitId,railId] of [['carriage','motionRailPosition','railEndValue','motionRail'],['homeCarriage','homeRailPosition','homeRailEnd','homeRail']]){
  const marker=$(markerId),rail=$(railId),label=$(labelId);
  marker.setAttribute('visibility',known?'visible':'hidden');
  if(known){const x=24+252*(1-pos/travel);marker.setAttribute('transform','translate('+x.toFixed(2)+' 0)');}
  label.textContent=pos===null?'—':pos.toFixed(2)+' mm';
  $(limitId).textContent=travel===null?'—':travel.toFixed(1)+' mm';
  rail.setAttribute('aria-label',positionNote);
 }
 $('travelHint').textContent=positionNote;
 $('motionPositionNote').textContent=positionNote;
 $('motionLive').textContent=moving?msg('MOVING','يتحرك'):online()?msg('LIVE','مباشر'):'OFFLINE';
 $('cycleTravelLabel').textContent=msg('Cycle travel','المسافة المنفذة في الدورة');
 $('jogLimit').textContent=online()&&typeof liveStatus.travel_limit_mm==='number'?liveStatus.travel_limit_mm.toFixed(1)+' mm':msg('Not calibrated','غير معاير');
 $('homeStart').disabled=!online()||commandBusy||stopPending;
 const canStart=online()&&cap.start===true&&cap.travel_limited===true&&liveStatus.homed===true&&!liveStatus.home_skipped;
 $('homeStart').setAttribute('aria-describedby','startReadiness');
 $('homeStart').style.opacity=canStart?'1':'.65';
 $('startReadiness').textContent=canStart?msg('Ready to request START — confirmation required.','جاهز لطلب START بعد التأكيد.'):startBlock();
 $('startReadiness').style.color=canStart?'#82d9a5':'#ffbf75';
 $('homeStart').title=online()&&!cap.start?startBlock():'';
 $('homePause').disabled=!(online()&&(liveStatus.state==='running'||liveStatus.state==='paused'));
 $('homeStop').disabled=!online();$('homeReturn').disabled=!(online()&&!commandBusy&&!stopPending&&cap.home);
 $('pauseText').textContent=liveStatus.state==='paused'?msg('RESUME','استكمال'):msg('PAUSE','إيقاف مؤقت');
 for(const id of ['jogForward','jogBackward','fastToggle'])$(id).disabled=!allowJog();
 $('jogHome').disabled=!(online()&&!commandBusy&&!stopPending&&cap.home);$('jogMode').textContent=allowJog()?'JOG READY':status;
 $('fastToggle').classList.toggle('active',fastEnabled);$('fastState').textContent=fastEnabled?'ON':'OFF';
 $('inspectionText').textContent=msg('Jog is available only when the firmware permits it. Hold to move; release to stop.','الحركة اليدوية تعمل فقط لو الكنترول سمح بها؛ اضغط باستمرار واترك للإيقاف.');
 $('jogWarning').textContent=msg('Step counting is an estimate, not an encoder. A hardwired E-STOP and independent overtravel protection are required.','المكان محسوب من نبضات الموتور، مش إنكودر. لازم فصل طوارئ وحماية ميكانيكية مستقلة لنهاية المشوار.');
 $('warningDemo').querySelector('p').textContent=bad?msg('LINK LOST. Machine state UNKNOWN. Check the physical controller.','انقطع الاتصال؛ حالة الماكينة غير معروفة. راجع الكنترول فعليًا.'):
    online()?msg(liveStatus.relay_output_enabled?'RELAY OUTPUT ENABLED — verified commissioning required.':'MOTOR DRY RUN — welding output is not energized.', liveStatus.relay_output_enabled?'خرج اللحام مفعّل — يلزم اختبار واعتماد توصيلاته.':'حركة موتور بدون تشغيل خرج اللحام حاليًا.'):
             msg('Connect to ESP32; no simulated machine motion or fake readings.','اتصل بالكنترول؛ لا توجد حركة وهمية أو قراءات مفبركة.');
 $('networkMessage').textContent=online()?msg('Automatically authenticated to uArt-WC01.','تم الاتصال تلقائيًا بشبكة uArt-WC01 والتحقق من الكنترول.'):
   authRejected?msg('Pairing key rejected. Tap Change Pair Key.','مفتاح الربط غير صحيح. اضغط تغيير مفتاح الربط.'):
   bad?msg('Link lost; machine state is unknown. The app will reconnect when Wi-Fi is available.','انقطع الاتصال وحالة الماكينة غير معروفة. التطبيق هيحاول يتصل تلقائيًا لما الواي فاي يرجع.'):
   msg('Connect to uArt-WC01 using Android Wi-Fi settings. App reconnects automatically.','اتصل بشبكة uArt-WC01 من إعدادات واي فاي الموبايل، والتطبيق هيتصل تلقائيًا.');
 $('capMonitor').textContent=online()?(cap.monitor?'YES':'LOCKED'):'—';
 $('capSettings').textContent=online()?(cap.settings?'YES':'LOCKED'):'—';
 $('capMotor').textContent=online()?(cap.jog?'JOG READY':'LOCKED'):'—';
 $('capHome').textContent=online()?(cap.home?'YES':'LOCKED'):'—';
 $('capStart').textContent=online()?(cap.start?'YES':'LOCKED'):'—';
 const svalue=(name)=>online()&&typeof liveStatus[name]==='boolean'?(liveStatus[name]?'ACTIVE':'INACTIVE'):'NOT VERIFIED';
 $('diagHome').textContent=svalue('sensor_home');$('diagEnd').textContent=svalue('sensor_end');
 $('diagEstop').textContent=svalue('estop');$('diagHomed').textContent=svalue('homed');
 $('sensorStatus').textContent=online()?(liveStatus.homed?'HOME REFERENCED':'HOME REQUIRED'):'NOT REPORTED';
 $('configWarning').textContent=online()?msg('Settings are saved on ESP32. Set Travel Limit on the physical panel. Initial speed is not separately implemented.','الإعدادات تتحفظ في الكنترول. حد المشوار الآمن يتحدد من شاشة الكنترول. سرعة البداية المستقلة غير مفعّلة بعد.'):
 msg('Offline: you may edit a local draft, but no controller will be changed.','بدون اتصال تقدر تعدل مسودة فقط، مش هيتغير الكنترول.');
 if(online()&&!cap.start&&liveStatus.state!=='running'&&liveStatus.state!=='paused')$('warningDemo').querySelector('p').textContent=startBlock();
 if(online()&&!allowJog())$('jogWarning').textContent=liveStatus.homed&&cap.travel_limited?msg('For manual JOG, open READY on controller (FAST from weld settings) or PAUSE an active job.','للتحريك اليدوي افتح جاهز للبدء على الكنترول (FAST من إعدادات اللحام) أو أوقف اللحام مؤقتًا.'):startBlock();
 const manufacturer=LEGAL_COMPANY;
 $('infoManufacturer').textContent=manufacturer;$('infoSerial').textContent=info.serial||msg('Not assigned','غير محدد');
 $('infoLength').textContent=info.nominalLength+' mm';$('infoUsable').textContent=info.usableTravel?info.usableTravel+' mm':msg('Not calibrated','غير معاير');
 $('infoFW').textContent=online()?firmware:msg('Not connected','غير متصل');
}
function showSheet(id){$(id).classList.remove('hidden');document.body.style.overflow='hidden'}
function hideSheet(id){$(id).classList.add('hidden');if(!$$('.overlay:not(.hidden)').length)document.body.style.overflow=''}
function hideAll(){for(const id of ['infoOverlay','editOverlay','confirmOverlay'])hideSheet(id)}
function confirmAction(title,detail,cb){pendingConfirm=cb;$('confirmTitle').textContent=title;$('confirmText').textContent=detail;showSheet('confirmOverlay')}
function editMachine(){hideSheet('infoOverlay');$('editSerial').value=info.serial;$('editLength').value=info.nominalLength;$('editUsable').value=info.usableTravel||'';showSheet('editOverlay')}
function saveMachine(){const length=Number($('editLength').value),raw=$('editUsable').value.trim(),travel=raw===''?null:Number(raw);
 if(!Number.isFinite(length)||length<100||length>10000||travel!==null&&(!Number.isFinite(travel)||travel<=0||travel>length)){notify(msg('Check rail and travel lengths.','راجع طول السكة والمشوار.'));return}
 info.serial=$('editSerial').value.slice(0,50);info.nominalLength=length;info.usableTravel=travel;put('machine',{serial:info.serial,nominalLength:length,usableTravel:travel});hideSheet('editOverlay');render();logEvent('Machine identification updated locally')}
function validBase(raw){try{const x=new URL(raw);if(x.protocol!=='http:'||x.username||x.password||x.search||x.hash||x.pathname!=='/')return false;
 const a=x.hostname.split('.').map(Number);return a.length===4&&a.every(n=>Number.isInteger(n)&&n>=0&&n<=255)&&
 (a[0]===10||(a[0]===172&&a[1]>=16&&a[1]<=31)||(a[0]===192&&a[1]===168))}catch{return false}}
async function api(path,method='GET',args){if(!authorization)throw Error('PAIRING_REQUIRED');
 const controller=new AbortController();const clock=setTimeout(()=>controller.abort(),2200);
 try{const rsp=await fetch(apiBase+path,{method,cache:'no-store',signal:controller.signal,
 headers:{'X-WC01-Key':authorization,...(args?{'Content-Type':'application/x-www-form-urlencoded'}:{})},
 ...(args?{body:new URLSearchParams(args)}:{})});
 const body=await rsp.json().catch(()=>null);if(!rsp.ok||!body||body.ok!==true)throw Error(body?.error||'HTTP '+rsp.status);return body;
 }finally{clearTimeout(clock)}}
function applyStatus(s){if(s?.ok!==true||s?.device!=='WC01'||typeof s?.state!=='string'||!s.cap)throw Error('UNRECOGNIZED_FIRMWARE');
 const previous=online()?liveStatus.state:null;
 if(Number.isInteger(s.jog_epoch)&&s.jog_epoch>=0&&s.jog_epoch<=0xffffffff&&!stopPending)jogEpoch=s.jog_epoch;
 liveStatus=s;cap=s.cap;firmware=s.firmware||'WC01';connection='connected';lastValid=Date.now();
 for(const [name,field] of Object.entries({speed:'speed',distance:'distance',pulse:'pulse',jog:'jog',fast:'fast',lead:'lead',sleep:'sleep',weldingType:'welding_type',direction:'direction',autoReturn:'auto_return'})){
  if(name==='autoReturn')config[name]=s[field]===true;else if(Number.isFinite(Number(s[field])))config[name]=Number(s[field]);
 }
 config.pulseEnabled=Number(config.pulse)>0;
 if(previous!==null&&previous!==s.state)logEvent('Controller state: '+previous+' -> '+s.state);
 render();}
// Automatic controller connection: fixed ESP32 AP address; no in-app Wi-Fi sign-in.
async function connect(){
 if(online()||reconnectBusy||authRejected||document.hidden)return;
 const key=readPairedKey();
 if(key.length<18){connection='disconnected';render();return}
 reconnectBusy=true;apiBase='http://192.168.4.1';authorization=key;connection='connecting';render();
 try{applyStatus(await api('/api/status'));linkError='';
  if(pollTimer)clearInterval(pollTimer);pollTimer=setInterval(poll,400);
  logEvent('Automatically authenticated to '+firmware);}
 catch(e){linkError=String(e.message);authRejected=linkError==='PAIRING_FAILED';
  connection='disconnected';authorization='';cap={};liveStatus={};render();
  if(authRejected){notify(msg('Controller rejected Pair Key. Update it once.','الكنترول رفض مفتاح الربط. عدّله مرة واحدة.'));if($('intro').classList.contains('hidden'))showPairing();}
 }finally{reconnectBusy=false}
}
async function poll(){if(!online()||pollBusy||commandBusy||stopPending)return;pollBusy=true;const gen=statusGeneration;const key=authorization;
 try{const data=await api('/api/status');if(gen===statusGeneration&&key===authorization&&online())applyStatus(data)}catch(e){if(gen===statusGeneration&&Date.now()-lastValid>2600)markLost(e.message)}finally{pollBusy=false}}
function markLost(why){if(connection==='lost')return;commandGeneration++;statusGeneration++;stopJog(false);connection='lost';authorization='';cap={};liveStatus={};clearInterval(pollTimer);pollTimer=null;
 logEvent('Wi-Fi connection lost, actual machine status unknown: '+why,'warn');render();notify(msg('LINK LOST — check physical machine.','انقطع الاتصال؛ افحص الماكينة فعليًا.'))}
function startAutoReconnect(){if(reconnectTimer)clearInterval(reconnectTimer);
 reconnectTimer=setInterval(()=>{if(!online()&&!reconnectBusy&&!authRejected)connect()},3500);
 connect();}
window.__wc01NetworkChanged=()=>{if(!online()){authorization='';connection='disconnected';render();connect()}};
function stopJog(sendStop=true){
 const had=holdDir!==0;holdDir=0;jogGeneration++;clearInterval(jogTimer);jogTimer=null;$$('.jog-button').forEach(e=>e.classList.remove('holding'));
 if(sendStop&&had&&online()){
  stopPending=true;statusGeneration++;
  const key=authorization;
  api('/api/jog','POST',{dir:'stop'}).then(r=>{if(key===authorization&&Number.isInteger(r.jog_epoch))jogEpoch=r.jog_epoch})
   .catch(e=>{logEvent('JOG stop not confirmed: '+e.message,'warn');notify(msg('Jog stop not confirmed; check physical controller.','لم يتأكد توقف الحركة؛ راجع الكنترول فعليًا.'))})
   .finally(()=>{stopPending=false;render();poll()});
 }
}
function startBlock(){
 if(!online())return msg('Connect to controller','اتصل بالكنترول');
 if(liveStatus.state==='fault'||Number(liveStatus.fault_code)>0)return Number(liveStatus.fault_code)===8?msg('F8: END limit active. Inspect sensor and clear fault at panel.','F8: حساس نهاية المشوار نشط؛ افحصه وأزل العطل من الكنترول.'):msg('Motion fault F','عطل حركة F')+String(liveStatus.fault_code||'?');
 if(liveStatus.recovery_pending)return msg('Resolve stored job on controller','حل حالة برنامج اللحام المحفوظ من الكنترول');
 if(!liveStatus.homed||liveStatus.home_skipped)return msg('Complete real HOME first','نفّذ HOME الحقيقي أولًا');
 if(cap.travel_limited!==true||!(Number(liveStatus.travel_limit_mm)>5))return msg('Panel: General Settings > Extra > Travel Limit. Enter measured safe travel, not nominal length.','من الكنترول: الإعدادات العامة > إضافية > Travel Limit. أدخل المشوار الآمن المقاس، مش طول السكة الاسمي.');
 if(liveStatus.backlight_on===false)return msg('Wake controller display','شغّل شاشة الكنترول');
 if(liveStatus.motor_jogging)return msg('Release manual jog','اترك زر الحركة اليدوية');
 if(liveStatus.state==='running'||liveStatus.state==='paused')return msg('Job already active; use PAUSE/RESUME or STOP','فيه برنامج قائم؛ استخدم إيقاف/استكمال أو STOP');
 if(Number(liveStatus.pulse)>5&&liveStatus.relay_output_enabled===true)return msg('Relay limit: 5 Hz on this firmware','حد الريلاي في الكود الحالي 5 هرتز');
 const p=liveStatus.position_mm,d=Number(liveStatus.distance),limit=Number(liveStatus.travel_limit_mm)-5,rev=Number(liveStatus.direction)===1;
 if(typeof p==='number'&&Number.isFinite(d)){
  if(rev&&(p<=0||liveStatus.sensor_home))return msg('At HOME: choose FWD','عند HOME؛ اختار FWD');
  if(!rev&&liveStatus.sensor_end)return msg('END sensor active','حساس نهاية المشوار نشط');
  const available=Math.max(0,rev?p:limit-p);
  if(p+(rev?-d:d)<0||p+(rev?-d:d)>limit+0.01)return msg('Distance exceeds safe travel. Available: ','المسافة أكبر من المتاح في الاتجاه المختار: ')+available.toFixed(1)+' mm';
 }
 if(![4,5,6,11].includes(Number(liveStatus.page)))return msg('Open MAIN, weld settings or READY on controller.','افتح القائمة الرئيسية أو إعدادات اللحام أو READY على الكنترول.');
 return msg('Controller interlock: check panel state','الكنترول مانع الأمر؛ راجع حالة الشاشة');
}
function commandPermitted(cmd,data,extra={}){
 if(cmd==='panel_key')return data.panel_keys===true&&String(data.page)===extra.page&&String(data.panel_selection)===extra.selection&&(extra.key==='wake'?data.backlight_on===false:panelHas(extra.key,data));
 if(cmd==='start')return data.cap?.start===true&&data.homed===true&&data.cap.travel_limited===true;
 if(cmd==='home')return data.cap?.home===true;
 if(cmd==='resume')return data.state==='paused';
 if(cmd==='speed')return canLiveSpeed(data);
 return true;
}
async function sendCommand(cmd,extra={}){
 if(!online()){notify(msg('No confirmed controller connection.','مفيش اتصال مؤكد بالكنترول.'));return}
 if(cmd==='stop'){
  commandGeneration++;statusGeneration++;stopJog();
  try{const r=await api('/api/command','POST',{cmd:'stop'});logEvent('Controller acknowledged STOP');notify(msg('STOP acknowledged; verify physical stop.','الكنترول أكد STOP؛ اتأكد من التوقف فعليًا.'))}
  catch(e){logEvent('STOP not confirmed: '+e.message,'warn');notify(msg('STOP not confirmed. Use hardwired E-STOP.','لم يتأكد STOP؛ استخدم الطوارئ الكهربائية.'))}
  finally{poll()}
  return;
 }
 if(commandBusy){notify(msg('Previous command pending','الأمر السابق لسه جاري'));return}
 if(holdDir||stopPending){stopJog();notify(msg('Release JOG and wait for stop','اترك الحركة اليدوية وانتظر التوقف'));return}
 commandBusy=true;statusGeneration++;const gen=++commandGeneration,key=authorization;
 let sent=false;render();
 try{
  const data=await api('/api/status');
  if(gen!==commandGeneration||key!==authorization||!online()||document.hidden)return;
  applyStatus(data);
  if(!commandPermitted(cmd,data,extra))throw Error(cmd==='start'?startBlock():'CONTROLLER_INTERLOCK');
  const nonce=data.command_nonce;
  if(['start','home','resume','speed','panel_key'].includes(cmd)&&(!Number.isInteger(nonce)||nonce<0||nonce>0xffffffff))throw Error('FIRMWARE_NONCE_REQUIRED');
  sent=true;
  await api('/api/command','POST',{cmd,...extra,...(Number.isInteger(nonce)?{nonce:String(nonce)}:{})});
  if(cmd==='speed')liveSpeedDraft=false;
  if(gen!==commandGeneration){if(online()&&key===authorization)await api('/api/command','POST',{cmd:'stop'});return}
  logEvent('Controller acknowledged '+cmd.toUpperCase());notify(msg('Command acknowledged: ','تم تأكيد الأمر: ')+cmd.toUpperCase());
 }catch(e){
  if(gen!==commandGeneration&&sent&&online()&&key===authorization){try{await api('/api/command','POST',{cmd:'stop'})}catch{}}
  if(gen===commandGeneration){logEvent('Command rejected or unconfirmed: '+cmd+' / '+e.message,'warn');notify(msg('Command rejected or unconfirmed: ','الأمر مرفوض أو لم يتأكد: ')+e.message)}
 }finally{commandBusy=false;render();await poll()}
}
function adjustLiveSpeed(delta){
 const current=numericField($('liveSpeedInput').value)??numericField(liveStatus.speed_mm_s);
 if(current===null)return;liveSpeedDraft=true;$('liveSpeedInput').value=Math.min(66.66,Math.max(.01,current+delta)).toFixed(2);
}
function applyLiveSpeed(){
 if(!online()||!canLiveSpeed(liveStatus)||commandBusy||stopPending){notify(msg('Live speed requires active welding.','تعديل السرعة يحتاج لحامًا شغالًا.'));return}
 const speed=numericField($('liveSpeedInput').value);
 if(speed===null||speed<.01||speed>66.66){notify(msg('Enter 0.01–66.66 mm/s within approved machine limits.','أدخل سرعة من 0.01 إلى 66.66 مم/ث ضمن حدود الماكينة المعتمدة.'));return}
 confirmAction(msg('Confirm live speed','تأكيد تعديل السرعة'),msg('Set welding speed to ','ضبط سرعة اللحام على ')+speed.toFixed(2)+' mm/s',()=>sendCommand('speed',{mm_s:speed.toFixed(2)}));
}
function actStart(){if(!online()||!cap.start||!liveStatus.homed||liveStatus.home_skipped||cap.travel_limited!==true){notify(startBlock());return}
 confirmAction(msg('Confirm remote START','تأكيد بدء التشغيل عن بُعد'),msg('Verify independent hardwired E-STOP, limits, clamp and clear work area before remote motion.','اتأكد من الطوارئ الكهربائية المستقلة والحساسات وتثبيت المشغولة وخلو مسار الحركة.'),()=>sendCommand('start'))}
function actPause(){sendCommand(liveStatus.state==='paused'?'resume':'pause')}
function actStop(){stopJog();if(!online()){notify(msg('Cannot confirm STOP. Use physical E-STOP if necessary.','مش قادر أؤكد STOP؛ استخدم فصل الطوارئ الفعلي عند الحاجة.'));return}
 sendCommand('stop')}
function actHome(){if(!online()||!cap.home){notify(msg('HOME is locked until sensors and homing are verified.','HOME مقفول لحين اعتماد الحساسات والمعايرة.'));return}
 confirmAction(msg('Confirm HOME','تأكيد الرجوع للأصل'),msg('Verify hardwired E-STOP and a clear travel path.','اتأكد من الطوارئ الكهربائية المستقلة وخلو مسار الحركة.'),()=>sendCommand('home'))}
function changeWeldType(v){go('settings');draftType=v;$('settingsModeTIG').classList.toggle('active',v===0);$('settingsModeCO2').classList.toggle('active',v===1);
 notify(msg('Select mode, then Save Settings to apply on ESP32.','اختار الوضع واضغط حفظ الإعدادات لإرساله للكنترول.'))}
function setFast(){if(!allowJog())return;fastEnabled=!fastEnabled;render();logEvent('Phone jog FAST '+(fastEnabled?'ON':'OFF'))}
let jogBusy=false;
async function jogLease(){if(!holdDir||!allowJog()||jogBusy)return;
 const gen=jogGeneration; jogBusy=true;
 try{const result=await api('/api/jog','POST',{dir:holdDir===1?'forward':'backward',fast:fastEnabled?'1':'0',epoch:jogEpoch});
  if(!result.ok)throw Error('JOG_REJECTED');
 }catch(e){if(holdDir&&gen===jogGeneration){logEvent('JOG stopped: '+e.message,'warn');notify(msg('JOG rejected: ','رفض الحركة: ')+e.message);stopJog();}}
 finally{jogBusy=false}}
function startJog(dir,e){if(e?.cancelable)e.preventDefault();if(!allowJog()||holdDir||jogBusy)return;
 jogGeneration++;holdDir=dir;$(dir===1?'jogForward':'jogBackward').classList.add('holding');
 logEvent('Phone JOG requested '+(dir===1?'FORWARD':'BACKWARD'));
 jogLease();jogTimer=setInterval(jogLease,120)}
function releaseJog(dir){if(holdDir===dir)stopJog()}
function fillForm(){draftType=config.weldingType;$('settingsModeTIG').classList.toggle('active',draftType===0);$('settingsModeCO2').classList.toggle('active',draftType===1);
 for(const [id,key] of Object.entries({fSpeed:'speed',fDistance:'distance',fPulse:'pulse',fInitial:'initial',fJog:'jog',fFast:'fast',fLead:'lead',fSleep:'sleep',fDirection:'direction'}))$(id).value=String(config[key]??'');
 $('fPulseEnable').checked=!!config.pulseEnabled;$('fReturn').checked=!!config.autoReturn}
function formConfig(){const next={...config};const constraints={speed:[.1,4000],distance:[.1,1000],pulse:[0,5],jog:[.1,4000],fast:[.1,4000],lead:[.1,40],sleep:[.1,60]};
 for(const [k,[lo,hi]] of Object.entries(constraints)){const id={speed:'fSpeed',distance:'fDistance',pulse:'fPulse',jog:'fJog',fast:'fFast',lead:'fLead',sleep:'fSleep'}[k];
  const n=Number($(id).value);if(!$(id).value.trim()||!Number.isFinite(n)||n<lo||n>hi){notify(msg('Invalid value: ','قيمة غير صحيحة: ')+k);$(id).focus();return null}next[k]=n}
 next.weldingType=draftType;next.direction=Number($('fDirection').value);next.pulseEnabled=$('fPulseEnable').checked;next.autoReturn=$('fReturn').checked;
 if(!next.pulseEnabled)next.pulse=0;
 if(online()&&Number.isFinite(Number(liveStatus.lead)))next.lead=Number(liveStatus.lead);
 return next}
async function saveSettings(){const values=formConfig();if(!values)return;
 if(!online()){Object.assign(config,values);put('draft',config);logEvent('Offline settings draft saved (not sent)');notify(msg('Saved locally only. Connect to ESP32 to apply.','اتحفظت على الموبايل فقط، اتصل بالكنترول للتطبيق.'));return}
 if(!cap.settings){notify(msg('Controller does not support settings write.','الكنترول مش بيسمح بتعديل الإعدادات.'));return}
 if(commandBusy||stopPending||liveStatus.state==='running'||liveStatus.state==='paused'||liveStatus.state==='homing'||liveStatus.state==='preview_locked'||liveStatus.motor_jogging){notify(msg('Controller busy. Stop motion first.','الكنترول مشغول؛ وقف الحركة الأول.'));return}
 stopJog();const args={speed:values.speed,distance:values.distance,pulse:values.pulse,jog:values.jog,fast:values.fast,lead:values.lead,sleep:values.sleep,
  weldingType:values.weldingType,direction:values.direction,autoReturn:values.autoReturn?1:0};
 try{await api('/api/config','POST',args);Object.assign(config,values);put('draft',config);logEvent('Settings saved on ESP32 NVS');notify(msg('ESP32 confirmed settings save.','الكنترول أكد حفظ الإعدادات.'));await poll()}
 catch(e){logEvent('Settings write rejected: '+e.message,'warn');notify(msg('Could not save on controller: ','فشل الحفظ في الكنترول: ')+e.message)}}
function renderPrograms(){const list=$('presetList');list.replaceChildren();$('programCount').textContent=String(presets.length);
 if(!presets.length){const e=document.createElement('p');e.className='empty-state';e.textContent=msg('No programs saved yet.','مفيش برامج محفوظة لسه.');list.append(e);return}
 for(const p of presets){const card=document.createElement('div');card.className='program';const title=document.createElement('strong');title.textContent=p.name;title.className='program-name';
  const details=document.createElement('p');details.className='program-params';details.textContent=`${p.config.speed} mm/min  ·  ${p.config.distance} mm  ·  ${p.config.pulse} Hz`;
  const actions=document.createElement('div');actions.className='program-actions';const load=document.createElement('button');load.textContent=msg('Load settings','تحميل الإعدادات');load.onclick=()=>{Object.assign(config,p.config);go('settings');notify(msg('Preset loaded into fields. Press Save Settings to send.','الإعدادات ظهرت؛ اضغط حفظ لإرسالها للكنترول.'))};
  const del=document.createElement('button');del.textContent=msg('Delete','حذف');del.className='delete-btn';del.onclick=()=>confirmAction(msg('Delete program?','حذف البرنامج؟'),p.name,()=>{presets=presets.filter(x=>x.id!==p.id);put('programs',presets);renderPrograms();logEvent('Deleted program: '+p.name)});
  actions.append(load,del);card.append(title,details,actions);list.append(card)}}
function savePreset(){const name=$('presetName').value.trim();if(name.length<2){notify(msg('Enter a valid program name.','اكتب اسم للبرنامج.'));return}
 const values=formConfigFromState();presets.unshift({id:Date.now()+'-'+Math.random().toString(36).slice(2,7),name:name.slice(0,40),config:values});presets=presets.slice(0,40);put('programs',presets);
 $('presetName').value='';renderPrograms();logEvent('Program saved locally: '+name);notify(msg('Saved on phone, not sent to controller.','اتحفظ على الموبايل فقط، مش على الكنترول.'))}
function formConfigFromState(){return {...config}}
let introTimer=null;
function introTo(i){$$('.intro-slide').forEach(el=>el.classList.toggle('active',Number(el.dataset.scene)===i));$('enterApp').classList.toggle('hidden',i!==2);
 clearTimeout(introTimer);introTimer=setTimeout(()=>enterApp(),1800)}
function enterApp(){clearTimeout(introTimer);put('introSeen',true);$('intro').classList.add('hidden');$('app').classList.remove('hidden');restorePanelFab();go('home');if(!readPairedKey()&&!pairingDialogUsed)setTimeout(showPairing,300);else connect()}
function bind(){
 bindFloatingPanel();
 $('skipIntro').onclick=enterApp;$('enterApp').onclick=enterApp;
 $('langBtn').onclick=()=>setLanguage(language==='ar'?'en':'ar');
 $('infoBtn').onclick=$('machineInfoOpen').onclick=()=>showSheet('infoOverlay');
 $('closeInfo').onclick=()=>hideSheet('infoOverlay');$('editInfo').onclick=editMachine;
 $('closeEdit').onclick=()=>hideSheet('editOverlay');$('saveInfo').onclick=saveMachine;
 $('cancelConfirm').onclick=$('cancelCross').onclick=()=>{pendingConfirm=null;hideSheet('confirmOverlay')};
 $('acceptConfirm').onclick=()=>{const cb=pendingConfirm;pendingConfirm=null;hideSheet('confirmOverlay');cb?.()};
 $$('.overlay').forEach(el=>el.addEventListener('click',e=>{if(e.target===el)hideSheet(el.id)}));
 $$('[data-go]').forEach(el=>el.onclick=()=>go(el.dataset.go));
 $('openConnection').onclick=()=>{if(online())go('machine');else if(!readPairedKey()||authRejected)showPairing();else openPhoneWiFi()};$('homeBack').onclick=()=>go('motion');
 $('liveSpeedInput').oninput=()=>{liveSpeedDraft=true};$('liveSpeedMinus').onclick=()=>adjustLiveSpeed(-.1);$('liveSpeedPlus').onclick=()=>adjustLiveSpeed(.1);$('liveSpeedApply').onclick=applyLiveSpeed;
 $('homeStart').onclick=actStart;$('homePause').onclick=actPause;$('homeStop').onclick=actStop;$('homeReturn').onclick=actHome;
 $('jogHome').onclick=actHome;$('btnTIG').onclick=()=>changeWeldType(0);$('btnCO2').onclick=()=>changeWeldType(1);
 $('fastToggle').onclick=setFast;
 for(const [id,dir] of [['jogForward',1],['jogBackward',-1]]){const el=$(id);
  el.addEventListener('pointerdown',e=>{if(el.disabled)return;e.preventDefault();try{el.setPointerCapture(e.pointerId)}catch{}startJog(dir,e)});
  for(const name of ['pointerup','pointercancel','lostpointercapture','pointerleave'])el.addEventListener(name,()=>releaseJog(dir));
  el.addEventListener('contextmenu',e=>e.preventDefault());}
 window.addEventListener('blur',()=>stopJog());document.addEventListener('visibilitychange',()=>{if(document.hidden)stopJog();else connect()});window.addEventListener('pagehide',()=>stopJog());
 $('settingsModeTIG').onclick=()=>{draftType=0;$('settingsModeTIG').classList.add('active');$('settingsModeCO2').classList.remove('active')};
 $('settingsModeCO2').onclick=()=>{draftType=1;$('settingsModeCO2').classList.add('active');$('settingsModeTIG').classList.remove('active')};
 $('saveSettings').onclick=saveSettings;$('savePreset').onclick=savePreset;
 $('openSystemWiFi').onclick=openPhoneWiFi;
 $('changePairKey').onclick=()=>showPairing();
 $('pairWiFiSettings').onclick=openPhoneWiFi;
 $('pairCancel').onclick=hidePairing;
 $('pairSave').onclick=pairOnce;
 $('initialPairKey').addEventListener('keydown',e=>{if(e.key==='Enter')pairOnce()});
 $('pairShowKey').onclick=()=>{$('initialPairKey').type=$('initialPairKey').type==='password'?'text':'password'};
 $('clearEvents').onclick=()=>confirmAction(msg('Clear current screen?','مسح سجل الشاشة؟'),msg('Archived files will not be deleted.','ملفات الأرشيف مش هتتمسح.'),()=>{logs=[];put('events',[]);renderEvents();logEvent('Recent diagnostics screen cleared; archived files retained')});
 $('exportEvents').onclick=async()=>{logEvent('Archive export requested');const ok=await WC01LogArchive.exportArchive();if(!ok)notify(msg('Export failed.','فشل تصدير السجل.'))};
 document.addEventListener('keydown',e=>{if(e.key==='Escape'){if(floatingOpen&&!$('.overlay:not(.hidden)').length)toggleFloatingPanel(false);else{hideAll();hidePairing()}}});
}
window.__wc01Back=()=>{if(!$('pairOverlay').classList.contains('hidden')){hidePairing();return}if($$('.overlay:not(.hidden)').length){hideAll();return}if(!$('intro').classList.contains('hidden')){enterApp();return}if(floatingOpen){toggleFloatingPanel(false);return}if(currentPage!=='home')go('home')};
window.__wc01ArchiveExportDone=()=>{notify(msg('Diagnostics archive export completed.','تم تصدير السجل.'));refreshArchive()};
setLanguage(language);bind();renderPrograms();renderEvents();render();refreshArchive();
logEvent('Application opened · uArt WC-01 v6.1.5 · Floating panel');
startAutoReconnect();
if(get('introSeen',false))enterApp();else introTo(1);
})();
